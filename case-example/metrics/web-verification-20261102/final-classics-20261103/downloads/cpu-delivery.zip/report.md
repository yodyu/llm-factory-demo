# 数值监控验证报告
任务：ui-3dea5cbfa50d4154；流程：COMPLETED
工程通过、效果测量、业务达标分别记录；业务门槛以冻结需求和验收结果为准。

## A. 工程质量

```json
{
  "model_origin": "llm_api",
  "dependency_profile": "metrics-py312-stdlib/1",
  "image": "sha256:ec7e3f613d45080c580bed6c83b6404df77b17a7cb72be69bacc80cce954ed31",
  "prompt_version": "metrics-prompts/6",
  "candidates": [
    {
      "business_acceptance": {
        "checks": [],
        "status": "NOT_DEFINED"
      },
      "calibration": {
        "binding": {
          "config": {
            "direction": "upper",
            "method_id": "fixed_threshold",
            "threshold": 90.0
          },
          "dataset": {
            "image_id": "sha256:ec7e3f613d45080c580bed6c83b6404df77b17a7cb72be69bacc80cce954ed31",
            "knowledge_snapshot": "sha256:9bb94b5e6a37ddc26f472653b398cce33b9f5c175c49cee6bb9706938581dcca",
            "labels_sha256": "sha256:8c8b78419d8c02fa3875660f384b2ca28279a5eeaf144b58e442dcf65d259c6b",
            "manifest_sha256": "sha256:a0acb6ae387ad842597e0b2d38bdf9c03e944f269074c23fb2b75c7cd8ae293a"
          },
          "source": "sha256:9049eb1b5535ee01d96796b15f6433016b845e10f6c9b0aabd85390cbe8ceda5"
        },
        "labels_used": false,
        "rule": "fixed_parameter_unchanged",
        "threshold": 0.0
      },
      "calibration_status": "SUCCEEDED",
      "candidate_id": "fixed_upper_cpu_90_p3",
      "plan": {
        "candidate_id": "fixed_upper_cpu_90_p3",
        "capability_id": "capability-980278873da6192086687b800c048bd4ab9a43d94e9f70b85bbac707a6b8e7c2",
        "config": {
          "direction": "upper",
          "method_id": "fixed_threshold",
          "threshold": 90.0
        },
        "knowledge_ids": [
          "capability-980278873da6192086687b800c048bd4ab9a43d94e9f70b85bbac707a6b8e7c2",
          "chunk-6e26ee889962cededda5b592fdb65c8638e92974b684d337218eebe3bd42d952",
          "chunk-4cde96ee5d5f4c785edb11ca42de730e583dec8ac36327aa9388973ab7666a09",
          "chunk-7ac5e3104c65ea345ed16051fd2dfa6aeb1588f1584dc99ac7a53dec3b632191",
          "chunk-3478558ca578b2421a9eafa4318746e1999211f4102a9c0c15c0327f07b4cdc8"
        ],
        "limitations": [
          "阈值 90.0 和连续 3 点来自用户明确需求；不使用默认 85.0，也不根据训练数据校准。",
          "训练数据最大值远低于 90.0，因此 fit 只能确认存在有效训练观测，不能由该训练摘要证明阈值的业务效果。",
          "演示纠正：已移除未提供的知识引用，相关参数不再标记为知识依据。"
        ],
        "parameter_sources": {
          "direction": "user_explicit",
          "method_id": "user_explicit",
          "persistence_points": "user_explicit",
          "threshold": "user_explicit"
        },
        "persistence_points": 3,
        "selection_reason": "该能力支持 time_series_anomaly_detection、gauge/rate、upper 方向和单主机单指标场景，min_history=0，适合无需历史基线的 CPU 使用率固定阈值监控。用户明确要求“只使用固定阈值”、超过 90% 且连续 3 个采样点报警，因此采用 threshold=90.0、direction=upper、persistence_points=3。假设输入字段包含 timestamp、host_id、value，且 value 为 0 到 100 的百分数数值或 null；value=90 时分数为 0，不报警。"
      },
      "report": {
        "acceptance_status": "MEASURED_NO_ACCEPTANCE_THRESHOLD",
        "coverage": {
          "denominator": 240,
          "null_reason": null,
          "numerator": 240,
          "value": 1.0
        },
        "effect_status": "MEASURED",
        "engineering_status": "PASSED",
        "event": {
          "f1": {
            "denominator": 5,
            "null_reason": null,
            "numerator": 4,
            "value": 0.8
          },
          "fn": 1,
          "fp": 0,
          "pairs": [
            {
              "delay_seconds": 120.0,
              "prediction_id": "pred-0000",
              "truth_id": "truth-0000"
            },
            {
              "delay_seconds": 120.0,
              "prediction_id": "pred-0001",
              "truth_id": "truth-0002"
            }
          ],
          "precision": {
            "denominator": 2,
            "null_reason": null,
            "numerator": 2,
            "value": 1.0
          },
          "recall": {
            "denominator": 3,
            "null_reason": null,
            "numerator": 2,
            "value": 0.6666666666666666
          },
          "tp": 2,
          "unmatched_prediction_ids": [],
          "unmatched_truth_ids": [
            "truth-0001"
          ]
        },
        "execution_status": "SUCCEEDED",
        "matched_delay_seconds": {
          "maximum": 120.0,
          "median": 120.0,
          "missed_events": 1,
          "null_reason": null
        },
        "normal_false_alarms_per_host_hour": {
          "denominator": 13860,
          "null_reason": null,
          "numerator": 0,
          "value": 0.0
        },
        "peak_memory_bytes": null,
        "peak_memory_null_reason": "not_measured",
        "point": {
          "abstained_normal": 0,
          "f1": {
            "denominator": 13,
            "null_reason": null,
            "numerator": 8,
            "value": 0.6153846153846154
          },
          "fn": 5,
          "fp": 0,
          "precision": {
            "denominator": 4,
            "null_reason": null,
            "numerator": 4,
            "value": 1.0
          },
          "recall": {
            "denominator": 9,
            "null_reason": null,
            "numerator": 4,
            "value": 0.4444444444444444
          },
          "tn": 231,
          "total": 240,
          "tp": 4
        },
        "predicted_events": [
          {
            "end_at": "2026-01-03T01:38:00Z",
            "event_id": "pred-0000",
            "host_id": "sim-host-a",
            "metric": "cpu_utilization",
            "start_at": "2026-01-03T01:37:00Z",
            "trigger_at": "2026-01-03T01:37:00Z"
          },
          {
            "end_at": "2026-01-03T04:05:00Z",
            "event_id": "pred-0001",
            "host_id": "sim-host-a",
            "metric": "cpu_utilization",
            "start_at": "2026-01-03T04:02:00Z",
            "trigger_at": "2026-01-03T04:02:00Z"
          }
        ],
        "protocol": "metrics-evaluation/1",
        "runtime_seconds": 0.11033356562256813,
        "truth_events": [
          {
            "end_at": "2026-01-03T01:38:00Z",
            "event_id": "truth-0000",
            "host_id": "sim-host-a",
            "metric": "cpu_utilization",
            "start_at": "2026-01-03T01:35:00Z",
            "trigger_at": "2026-01-03T01:35:00Z"
          },
          {
            "end_at": "2026-01-03T03:01:00Z",
            "event_id": "truth-0001",
            "host_id": "sim-host-a",
            "metric": "cpu_utilization",
            "start_at": "2026-01-03T03:00:00Z",
            "trigger_at": "2026-01-03T03:00:00Z"
          },
          {
            "end_at": "2026-01-03T04:05:00Z",
            "event_id": "truth-0002",
            "host_id": "sim-host-a",
            "metric": "cpu_utilization",
            "start_at": "2026-01-03T04:00:00Z",
            "trigger_at": "2026-01-03T04:00:00Z"
          }
        ]
      },
      "role": "development",
      "versions": [
        {
          "capability_id": "capability-980278873da6192086687b800c048bd4ab9a43d94e9f70b85bbac707a6b8e7c2",
          "capability_version": "1.1.0",
          "explanation": "实现用户明确指定的固定上限阈值 CPU > 90%：upper 方向分数为 value - 90.0，等于 90 时分数为 0，只有严格大于 0 才成为异常候选。fit 仅确认训练集中存在有效数值；模型不维护历史，也不实现连续 3 点逻辑，持久化由可信侧告警器处理。",
          "knowledge_ids": [
            "capability-980278873da6192086687b800c048bd4ab9a43d94e9f70b85bbac707a6b8e7c2",
            "chunk-6e26ee889962cededda5b592fdb65c8638e92974b684d337218eebe3bd42d952",
            "chunk-4cde96ee5d5f4c785edb11ca42de730e583dec8ac36327aa9388973ab7666a09"
          ],
          "origin": "llm_api",
          "parent_source_sha256": null,
          "plugin_hashes": {
            "capability.json": "sha256:a19217ef27bff5c0726e6be8d4dc123a509bfe2d34c6fe8b63b0f2cd6c5ef045",
            "checks.py": "sha256:009933701326684689fb100d585f4bb44d596016fa7d9278147f6999566e9427",
            "reference.py": "sha256:8905463c215a83c37c295d265a4c6ef0d1f457911f7cae9320777ddb76c3ce70"
          },
          "source_path": "candidate-dc9b2f18f5619ee06db95e9689a3ef12f9c98a6ad2c153263b16bb37da87f460/v0.py",
          "source_ref": "sha256:9049eb1b5535ee01d96796b15f6433016b845e10f6c9b0aabd85390cbe8ceda5",
          "source_sha256": "sha256:9049eb1b5535ee01d96796b15f6433016b845e10f6c9b0aabd85390cbe8ceda5",
          "specification_sha256": "sha256:d78418b686499b015abb691e10e65fad63592d12ad25bcab36e2ced5af7a2060",
          "validation": {
            "candidate_id": "fixed_upper_cpu_90_p3",
            "capability_version": "1.1.0",
            "checks": [
              {
                "check": "static_profile",
                "layer": "contract",
                "passed": true
              },
              {
                "check": "missing_input_contract",
                "layer": "contract",
                "passed": true
              },
              {
                "check": "state_reload",
                "layer": "contract",
                "passed": true
              },
              {
                "check": "reset_repeat_future_invariance",
                "layer": "contract",
                "passed": true
              },
              {
                "check": "fixed_strict_boundary",
                "layer": "property",
                "passed": true,
                "points": 3
              },
              {
                "check": "fixed_missing",
                "layer": "property",
                "passed": true,
                "points": 6
              },
              {
                "check": "fixed_strict_boundary",
                "layer": "reference",
                "passed": true,
                "points": 3
              },
              {
                "check": "fixed_missing",
                "layer": "reference",
                "passed": true,
                "points": 6
              }
            ],
            "config": {
              "direction": "upper",
              "method_id": "fixed_threshold",
              "threshold": 90.0
            },
            "dependency_profile": "metrics-py312-stdlib/1",
            "origin": "llm_api",
            "passed": true,
            "plugin_hashes": {
              "capability.json": "sha256:a19217ef27bff5c0726e6be8d4dc123a509bfe2d34c6fe8b63b0f2cd6c5ef045",
              "checks.py": "sha256:009933701326684689fb100d585f4bb44d596016fa7d9278147f6999566e9427",
              "reference.py": "sha256:8905463c215a83c37c295d265a4c6ef0d1f457911f7cae9320777ddb76c3ce70"
            },
            "protocol": "metrics-method-check/3",
            "repairable": true,
            "source_sha256": "sha256:9049eb1b5535ee01d96796b15f6433016b845e10f6c9b0aabd85390cbe8ceda5",
            "verification_level": "reference_verified",
            "version": 0
          },
          "version": 0
        }
      ]
    }
  ],
  "stage_status": {
    "benchmark": "NOT_APPLICABLE",
    "detection": "SUCCEEDED",
    "engineering": "PASSED"
  },
  "model_usage": {
    "kind": "api",
    "requests": 2,
    "reservations": 2,
    "input_tokens": 29699,
    "output_tokens": 2454,
    "total_tokens": 32153,
    "missing_usage_requests": 0,
    "notice": "Counts include retries and repairs; tokens are provider-reported only; missing usage is not zero."
  },
  "workflow_runtime_seconds": 58.883552338927984,
  "resources": {
    "peak_memory_bytes": null,
    "cpu_seconds": null,
    "reason": "not_measured; sandbox limits are not measurements"
  },
  "peak_memory": "NOT_MEASURED; container limits are not measurements",
  "failure": null
}
```

## B. 当前检测数据

```json
{
  "frozen_source": {
    "display_name": "sim-cpu_spike-v1",
    "end_at_inclusive": "2026-01-04T04:59:00+00:00",
    "host_id": "sim-host-a",
    "metric": "cpu_utilization",
    "missing_points": 1,
    "points": 300,
    "roles": {
      "calibration": {
        "path": "calibration.csv",
        "prefix_points": 60,
        "sha256": "sha256:27a190fdb6fc43c4df21bb942e78a94f91b9c11507520e4d9f9b35630d2d8c9c"
      },
      "development": {
        "path": "development.csv",
        "prefix_points": 60,
        "sha256": "sha256:768084780526b7c955dd32a94fadef2e7c7215d8b2392924b80a517a6b8de629"
      },
      "test": {
        "path": "test.csv",
        "prefix_points": 60,
        "sha256": "sha256:04f05afad8d4426665a61b61329e6f505945c9a7848ca82a9ad9101b4181d988"
      },
      "train": {
        "path": "train.csv",
        "prefix_points": 60,
        "sha256": "sha256:018d3d5f0dff7c423c6a998a28f41434b34b6993b0955243a777b30bf523da67"
      }
    },
    "sampling_seconds": 60,
    "start_at": "2026-01-04T00:00:00+00:00",
    "type": "builtin_simulation",
    "unit": "percent"
  },
  "selection": {
    "basis": "labelled_development",
    "beta": 1.0,
    "criteria": [
      "event_f1_desc",
      "point_f1_desc",
      "false_alarm_rate_asc",
      "matched_delay_asc",
      "coverage_desc",
      "candidate_id"
    ],
    "objective": "event_detection",
    "policy": "balanced",
    "protocol": "metrics-selection/2",
    "ranking": [
      "fixed_upper_cpu_90_p3"
    ],
    "reason": "按开发集目标及次级 Fβ、正常误报频次、匹配延迟、覆盖率和候选ID排序；最终测试不参与选择。",
    "requested_policy": "balanced",
    "selected": "fixed_upper_cpu_90_p3",
    "status": "SELECTED",
    "tie_broken_by": "only_eligible_candidate",
    "warnings": [
      "LOW_EVENT_COUNT: 真实事件少于5个，事件F1不足以支持统计结论。"
    ]
  },
  "result": {
    "acceptance_status": "MEASURED_NO_ACCEPTANCE_THRESHOLD",
    "coverage": {
      "denominator": 240,
      "null_reason": null,
      "numerator": 240,
      "value": 1.0
    },
    "effect_status": "MEASURED",
    "engineering_status": "PASSED",
    "event": {
      "f1": {
        "denominator": 5,
        "null_reason": null,
        "numerator": 4,
        "value": 0.8
      },
      "fn": 1,
      "fp": 0,
      "pairs": [
        {
          "delay_seconds": 120.0,
          "prediction_id": "pred-0000",
          "truth_id": "truth-0000"
        },
        {
          "delay_seconds": 120.0,
          "prediction_id": "pred-0001",
          "truth_id": "truth-0002"
        }
      ],
      "precision": {
        "denominator": 2,
        "null_reason": null,
        "numerator": 2,
        "value": 1.0
      },
      "recall": {
        "denominator": 3,
        "null_reason": null,
        "numerator": 2,
        "value": 0.6666666666666666
      },
      "tp": 2,
      "unmatched_prediction_ids": [],
      "unmatched_truth_ids": [
        "truth-0001"
      ]
    },
    "execution_status": "SUCCEEDED",
    "matched_delay_seconds": {
      "maximum": 120.0,
      "median": 120.0,
      "missed_events": 1,
      "null_reason": null
    },
    "normal_false_alarms_per_host_hour": {
      "denominator": 13860,
      "null_reason": null,
      "numerator": 0,
      "value": 0.0
    },
    "peak_memory_bytes": null,
    "peak_memory_null_reason": "not_measured",
    "phase": "test",
    "point": {
      "abstained_normal": 0,
      "f1": {
        "denominator": 13,
        "null_reason": null,
        "numerator": 8,
        "value": 0.6153846153846154
      },
      "fn": 5,
      "fp": 0,
      "precision": {
        "denominator": 4,
        "null_reason": null,
        "numerator": 4,
        "value": 1.0
      },
      "recall": {
        "denominator": 9,
        "null_reason": null,
        "numerator": 4,
        "value": 0.4444444444444444
      },
      "tn": 231,
      "total": 240,
      "tp": 4
    },
    "predicted_events": [
      {
        "end_at": "2026-01-04T01:38:00Z",
        "event_id": "pred-0000",
        "host_id": "sim-host-a",
        "metric": "cpu_utilization",
        "start_at": "2026-01-04T01:37:00Z",
        "trigger_at": "2026-01-04T01:37:00Z"
      },
      {
        "end_at": "2026-01-04T04:05:00Z",
        "event_id": "pred-0001",
        "host_id": "sim-host-a",
        "metric": "cpu_utilization",
        "start_at": "2026-01-04T04:02:00Z",
        "trigger_at": "2026-01-04T04:02:00Z"
      }
    ],
    "protocol": "metrics-evaluation/1",
    "runtime_seconds": 0.09776228293776512,
    "selected": "fixed_upper_cpu_90_p3",
    "selection_sha256": "sha256:51480222f747b8a94a764f7e5861a4a7621b3b09325be8def0a98f1900179d14",
    "test_execution_started": true,
    "truth_events": [
      {
        "end_at": "2026-01-04T01:38:00Z",
        "event_id": "truth-0000",
        "host_id": "sim-host-a",
        "metric": "cpu_utilization",
        "start_at": "2026-01-04T01:35:00Z",
        "trigger_at": "2026-01-04T01:35:00Z"
      },
      {
        "end_at": "2026-01-04T03:01:00Z",
        "event_id": "truth-0001",
        "host_id": "sim-host-a",
        "metric": "cpu_utilization",
        "start_at": "2026-01-04T03:00:00Z",
        "trigger_at": "2026-01-04T03:00:00Z"
      },
      {
        "end_at": "2026-01-04T04:05:00Z",
        "event_id": "truth-0002",
        "host_id": "sim-host-a",
        "metric": "cpu_utilization",
        "start_at": "2026-01-04T04:00:00Z",
        "trigger_at": "2026-01-04T04:00:00Z"
      }
    ]
  },
  "notice": null
}
```

## C. 独立模拟基准效果

```json
{
  "notice": "这些指标属于独立模拟基准，不代表上传数据的准确率或生产效果。",
  "result": {
    "execution_status": "NOT_EVALUATED",
    "reason": "builtin simulation evaluated in B"
  }
}
```

## D. 需求理解与业务验收

```json
{
  "frozen_task": {
    "acceptance_criteria": {
      "max_false_alarms_per_hour": null,
      "min_event_f1": null,
      "min_event_recall": null
    },
    "allowed_methods": [
      "fixed_threshold"
    ],
    "anomaly_target": "upper",
    "budgets": {
      "candidates": 1,
      "model_calls": 16,
      "repair_rounds": 2,
      "wall_seconds": 900
    },
    "dataset_id": "sim-cpu_spike-v1",
    "evaluation_objective": "event_detection",
    "explicit_constraints": {
      "direction": "upper",
      "persistence_points": 3.0,
      "threshold": 90.0
    },
    "knowledge_snapshot": "sha256:9bb94b5e6a37ddc26f472653b398cce33b9f5c175c49cee6bb9706938581dcca",
    "metric": "cpu_utilization",
    "model_mode": "api",
    "model_profile_id": "metrics-c9a0036e73b91ba3",
    "ranking_preferences": [],
    "requirement": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
    "requirement_draft": {
      "binding": "sha256:b44aa5f27ab7fbb8441ce46aa7337a3cc6b06d994a6c99e2127013aff2fc84cc",
      "defaults": [
        "选优偏好：balanced",
        "模拟数据：每 60 秒一点，独立四段；允许最多前向填补 3 点。",
        "未明确变化形态：CPU默认突增、内存默认阶跃模拟场景；模拟结果不代表生产效果。"
      ],
      "evidence": {
        "data_source": {
          "origin": "user_explicit",
          "quote": "模拟",
          "turn": 1
        },
        "direction": {
          "origin": "user_explicit",
          "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
          "turn": 1
        },
        "evaluation_objective": {
          "origin": "user_explicit",
          "quote": "超过 90% 且连续 3 个采样点才报警",
          "turn": 1
        },
        "methods": {
          "origin": "user_explicit",
          "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
          "turn": 1
        },
        "persistence_points": {
          "origin": "user_explicit",
          "quote": "连续 3 个采样点",
          "turn": 1
        },
        "scenario": {
          "origin": "user_explicit",
          "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
          "turn": 1
        },
        "selection_policy": {
          "origin": "protocol_default",
          "quote": "协议默认值",
          "turn": 0
        },
        "threshold": {
          "origin": "user_explicit",
          "quote": "超过 90%",
          "turn": 1
        }
      },
      "issues": [],
      "model_mode": "api",
      "model_usage": {
        "input_tokens": 2194,
        "kind": "api",
        "missing_usage_requests": 0,
        "notice": "Counts include retries and repairs; tokens are provider-reported only; missing usage is not zero.",
        "output_tokens": 398,
        "requests": 2,
        "reservations": 2,
        "total_tokens": 2592
      },
      "parse_task_id": "understand-6e91d958fb314898",
      "revision": 1,
      "schema_version": "metrics-requirement-draft/1",
      "turns": [
        "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。"
      ],
      "values": {
        "data_source": "simulation",
        "direction": "upper",
        "evaluation_objective": "event_detection",
        "methods": [
          "fixed_threshold"
        ],
        "persistence_points": 3,
        "scenario": "cpu_spike",
        "selection_policy": "balanced",
        "threshold": 90.0
      }
    },
    "schema_version": "metrics-task/1",
    "selection_policy": "balanced",
    "task_id": "ui-3dea5cbfa50d4154",
    "validation_protocol": "metrics-evaluation/1"
  },
  "selection_explanation": {
    "评价目标": "事件发现",
    "实际选优偏好": "综合选优",
    "比较依据": "有标签开发集",
    "排序顺序": "开发事件 F1 → 开发点级 F1 → 开发正常误报频次（升序） → 开发匹配延迟（升序） → 开发覆盖率（降序） → 候选标识（稳定决胜）",
    "实际决胜项": "仅一个合格候选"
  },
  "evaluation_policy": null,
  "requirement": {
    "binding": "sha256:b44aa5f27ab7fbb8441ce46aa7337a3cc6b06d994a6c99e2127013aff2fc84cc",
    "defaults": [
      "选优偏好：balanced",
      "模拟数据：每 60 秒一点，独立四段；允许最多前向填补 3 点。",
      "未明确变化形态：CPU默认突增、内存默认阶跃模拟场景；模拟结果不代表生产效果。"
    ],
    "evidence": {
      "data_source": {
        "origin": "user_explicit",
        "quote": "模拟",
        "turn": 1
      },
      "direction": {
        "origin": "user_explicit",
        "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
        "turn": 1
      },
      "evaluation_objective": {
        "origin": "user_explicit",
        "quote": "超过 90% 且连续 3 个采样点才报警",
        "turn": 1
      },
      "methods": {
        "origin": "user_explicit",
        "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
        "turn": 1
      },
      "persistence_points": {
        "origin": "user_explicit",
        "quote": "连续 3 个采样点",
        "turn": 1
      },
      "scenario": {
        "origin": "user_explicit",
        "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
        "turn": 1
      },
      "selection_policy": {
        "origin": "protocol_default",
        "quote": "协议默认值",
        "turn": 0
      },
      "threshold": {
        "origin": "user_explicit",
        "quote": "超过 90%",
        "turn": 1
      }
    },
    "issues": [],
    "model_mode": "api",
    "model_usage": {
      "input_tokens": 2194,
      "kind": "api",
      "missing_usage_requests": 0,
      "notice": "Counts include retries and repairs; tokens are provider-reported only; missing usage is not zero.",
      "output_tokens": 398,
      "requests": 2,
      "reservations": 2,
      "total_tokens": 2592
    },
    "parse_task_id": "understand-6e91d958fb314898",
    "revision": 1,
    "schema_version": "metrics-requirement-draft/1",
    "turns": [
      "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。"
    ],
    "values": {
      "data_source": "simulation",
      "direction": "upper",
      "evaluation_objective": "event_detection",
      "methods": [
        "fixed_threshold"
      ],
      "persistence_points": 3,
      "scenario": "cpu_spike",
      "selection_policy": "balanced",
      "threshold": 90.0
    }
  },
  "acceptance": {
    "checks": [],
    "status": "NOT_DEFINED"
  },
  "criteria": {
    "max_false_alarms_per_hour": null,
    "min_event_f1": null,
    "min_event_recall": null
  }
}
```
