# 数值监控验证报告
任务：ui-34a756c1b4ac490b；流程：COMPLETED
工程通过、效果测量、业务达标分别记录；业务门槛以冻结需求和验收结果为准。

## A. 工程质量

```json
{
  "model_origin": "llm_api",
  "dependency_profile": "metrics-py312-stdlib/1",
  "image": "sha256:ec7e3f613d45080c580bed6c83b6404df77b17a7cb72be69bacc80cce954ed31",
  "prompt_version": "metrics-prompts/5",
  "candidates": [
    {
      "business_acceptance": {
        "checks": [],
        "status": "NOT_DEFINED"
      },
      "calibration": {
        "binding": {
          "config": {
            "direction": "upper",
            "method_id": "fixed_threshold",
            "threshold": 90.0
          },
          "dataset": {
            "image_id": "sha256:ec7e3f613d45080c580bed6c83b6404df77b17a7cb72be69bacc80cce954ed31",
            "knowledge_snapshot": "sha256:919e8bf13131bfe328ddfb4108fcb9eafc8673b74be9b85b774f428739151dcb",
            "labels_sha256": "sha256:8c8b78419d8c02fa3875660f384b2ca28279a5eeaf144b58e442dcf65d259c6b",
            "manifest_sha256": "sha256:c67fd69c76734856c25d568fa5b35f6caf020b14aafadd9bf167de10223cf9cb"
          },
          "source": "sha256:1cda364b1636b5325c6102212290ec2adca40c058f0369926bb2d53f97a0626a"
        },
        "labels_used": false,
        "rule": "fixed_parameter_unchanged",
        "threshold": 0.0
      },
      "calibration_status": "SUCCEEDED",
      "candidate_id": "fixed_threshold_cpu_upper_90_p3",
      "plan": {
        "candidate_id": "fixed_threshold_cpu_upper_90_p3",
        "capability_id": "capability-980278873da6192086687b800c048bd4ab9a43d94e9f70b85bbac707a6b8e7c2",
        "config": {
          "direction": "upper",
          "method_id": "fixed_threshold",
          "threshold": 90.0
        },
        "knowledge_ids": [
          "capability-980278873da6192086687b800c048bd4ab9a43d94e9f70b85bbac707a6b8e7c2",
          "chunk-6e26ee889962cededda5b592fdb65c8638e92974b684d337218eebe3bd42d952",
          "chunk-4cde96ee5d5f4c785edb11ca42de730e583dec8ac36327aa9388973ab7666a09",
          "chunk-7ac5e3104c65ea345ed16051fd2dfa6aeb1588f1584dc99ac7a53dec3b632191"
        ],
        "limitations": [
          "训练数据最大值远低于 90，但用户阈值优先；不依据训练分布改写阈值。",
          "连续点计数、事件合并不在 fixed_threshold 的 threshold/direction 参数内，需要执行阶段在共享可信告警器或程序外层实现。",
          "演示纠正：已移除未提供的知识引用，相关参数不再标记为知识依据。"
        ],
        "parameter_sources": {
          "direction": "user_explicit",
          "persistence_points": "user_explicit",
          "threshold": "user_explicit"
        },
        "persistence_points": 3,
        "selection_reason": "适配单主机单指标 gauge/rate 的 CPU 利用率异常检测，不需要历史基线，min_history=0；方法唯一且符合用户“只使用固定阈值”的约束。配置采用用户明确指定的 upper 与 threshold=90.0；score=x-90，严格 score>0 才进入异常候选，因此 90.0% 本身不触发。用户还明确要求连续 3 个采样点报警，故 persistence_points=3。假设输入记录包含 timestamp、host_id、value，且连续点判断按 60 秒采样顺序逐点执行；value 缺失时按能力契约输出 missing_input。"
      },
      "report": {
        "acceptance_status": "MEASURED_NO_ACCEPTANCE_THRESHOLD",
        "coverage": {
          "denominator": 240,
          "null_reason": null,
          "numerator": 240,
          "value": 1.0
        },
        "effect_status": "MEASURED",
        "engineering_status": "PASSED",
        "event": {
          "f1": {
            "denominator": 5,
            "null_reason": null,
            "numerator": 4,
            "value": 0.8
          },
          "fn": 1,
          "fp": 0,
          "pairs": [
            {
              "delay_seconds": 120.0,
              "prediction_id": "pred-0000",
              "truth_id": "truth-0000"
            },
            {
              "delay_seconds": 120.0,
              "prediction_id": "pred-0001",
              "truth_id": "truth-0002"
            }
          ],
          "precision": {
            "denominator": 2,
            "null_reason": null,
            "numerator": 2,
            "value": 1.0
          },
          "recall": {
            "denominator": 3,
            "null_reason": null,
            "numerator": 2,
            "value": 0.6666666666666666
          },
          "tp": 2,
          "unmatched_prediction_ids": [],
          "unmatched_truth_ids": [
            "truth-0001"
          ]
        },
        "execution_status": "SUCCEEDED",
        "matched_delay_seconds": {
          "maximum": 120.0,
          "median": 120.0,
          "missed_events": 1,
          "null_reason": null
        },
        "normal_false_alarms_per_host_hour": {
          "denominator": 13860,
          "null_reason": null,
          "numerator": 0,
          "value": 0.0
        },
        "peak_memory_bytes": null,
        "peak_memory_null_reason": "not_measured",
        "point": {
          "abstained_normal": 0,
          "f1": {
            "denominator": 13,
            "null_reason": null,
            "numerator": 8,
            "value": 0.6153846153846154
          },
          "fn": 5,
          "fp": 0,
          "precision": {
            "denominator": 4,
            "null_reason": null,
            "numerator": 4,
            "value": 1.0
          },
          "recall": {
            "denominator": 9,
            "null_reason": null,
            "numerator": 4,
            "value": 0.4444444444444444
          },
          "tn": 231,
          "total": 240,
          "tp": 4
        },
        "predicted_events": [
          {
            "end_at": "2026-01-03T01:38:00Z",
            "event_id": "pred-0000",
            "host_id": "sim-host-a",
            "metric": "cpu_utilization",
            "start_at": "2026-01-03T01:37:00Z",
            "trigger_at": "2026-01-03T01:37:00Z"
          },
          {
            "end_at": "2026-01-03T04:05:00Z",
            "event_id": "pred-0001",
            "host_id": "sim-host-a",
            "metric": "cpu_utilization",
            "start_at": "2026-01-03T04:02:00Z",
            "trigger_at": "2026-01-03T04:02:00Z"
          }
        ],
        "protocol": "metrics-evaluation/1",
        "runtime_seconds": 0.10557932406663895,
        "truth_events": [
          {
            "end_at": "2026-01-03T01:38:00Z",
            "event_id": "truth-0000",
            "host_id": "sim-host-a",
            "metric": "cpu_utilization",
            "start_at": "2026-01-03T01:35:00Z",
            "trigger_at": "2026-01-03T01:35:00Z"
          },
          {
            "end_at": "2026-01-03T03:01:00Z",
            "event_id": "truth-0001",
            "host_id": "sim-host-a",
            "metric": "cpu_utilization",
            "start_at": "2026-01-03T03:00:00Z",
            "trigger_at": "2026-01-03T03:00:00Z"
          },
          {
            "end_at": "2026-01-03T04:05:00Z",
            "event_id": "truth-0002",
            "host_id": "sim-host-a",
            "metric": "cpu_utilization",
            "start_at": "2026-01-03T04:00:00Z",
            "trigger_at": "2026-01-03T04:00:00Z"
          }
        ]
      },
      "role": "development",
      "versions": [
        {
          "capability_id": "capability-980278873da6192086687b800c048bd4ab9a43d94e9f70b85bbac707a6b8e7c2",
          "capability_version": "1.1.0",
          "explanation": "实现用户明确指定的固定阈值检测：direction=upper，threshold=90.0。score=value-90，等于 90 时 score 为 0，严格大于 0 才作为异常候选；缺失值返回 missing_input，非法数值返回 invalid_input。fit 只确认存在有效训练值，reset 不保留运行期历史。连续 3 个采样点由外层可信告警器处理，检测器本身不实现持久化计数。",
          "knowledge_ids": [
            "capability-980278873da6192086687b800c048bd4ab9a43d94e9f70b85bbac707a6b8e7c2",
            "chunk-6e26ee889962cededda5b592fdb65c8638e92974b684d337218eebe3bd42d952",
            "chunk-4cde96ee5d5f4c785edb11ca42de730e583dec8ac36327aa9388973ab7666a09",
            "chunk-7ac5e3104c65ea345ed16051fd2dfa6aeb1588f1584dc99ac7a53dec3b632191"
          ],
          "origin": "llm_api",
          "parent_source_sha256": null,
          "plugin_hashes": {
            "capability.json": "sha256:a19217ef27bff5c0726e6be8d4dc123a509bfe2d34c6fe8b63b0f2cd6c5ef045",
            "checks.py": "sha256:009933701326684689fb100d585f4bb44d596016fa7d9278147f6999566e9427",
            "reference.py": "sha256:8905463c215a83c37c295d265a4c6ef0d1f457911f7cae9320777ddb76c3ce70"
          },
          "source_path": "candidate-6e556c02624664f884d552b08ca090710acb4dc9c627b97f2d129c9a226c44d5/v0.py",
          "source_ref": "sha256:1cda364b1636b5325c6102212290ec2adca40c058f0369926bb2d53f97a0626a",
          "source_sha256": "sha256:1cda364b1636b5325c6102212290ec2adca40c058f0369926bb2d53f97a0626a",
          "specification_sha256": "sha256:d78418b686499b015abb691e10e65fad63592d12ad25bcab36e2ced5af7a2060",
          "validation": {
            "candidate_id": "fixed_threshold_cpu_upper_90_p3",
            "capability_version": "1.1.0",
            "checks": [
              {
                "check": "static_profile",
                "layer": "contract",
                "passed": true
              },
              {
                "check": "missing_input_contract",
                "layer": "contract",
                "passed": true
              },
              {
                "check": "state_reload",
                "layer": "contract",
                "passed": true
              },
              {
                "check": "reset_repeat_future_invariance",
                "layer": "contract",
                "passed": true
              },
              {
                "check": "fixed_strict_boundary",
                "layer": "property",
                "passed": true,
                "points": 3
              },
              {
                "check": "fixed_missing",
                "layer": "property",
                "passed": true,
                "points": 6
              },
              {
                "check": "fixed_strict_boundary",
                "layer": "reference",
                "passed": true,
                "points": 3
              },
              {
                "check": "fixed_missing",
                "layer": "reference",
                "passed": true,
                "points": 6
              }
            ],
            "config": {
              "direction": "upper",
              "method_id": "fixed_threshold",
              "threshold": 90.0
            },
            "dependency_profile": "metrics-py312-stdlib/1",
            "origin": "llm_api",
            "passed": true,
            "plugin_hashes": {
              "capability.json": "sha256:a19217ef27bff5c0726e6be8d4dc123a509bfe2d34c6fe8b63b0f2cd6c5ef045",
              "checks.py": "sha256:009933701326684689fb100d585f4bb44d596016fa7d9278147f6999566e9427",
              "reference.py": "sha256:8905463c215a83c37c295d265a4c6ef0d1f457911f7cae9320777ddb76c3ce70"
            },
            "protocol": "metrics-method-check/3",
            "repairable": true,
            "source_sha256": "sha256:1cda364b1636b5325c6102212290ec2adca40c058f0369926bb2d53f97a0626a",
            "verification_level": "reference_verified",
            "version": 0
          },
          "version": 0
        }
      ]
    }
  ],
  "stage_status": {
    "benchmark": "NOT_APPLICABLE",
    "detection": "SUCCEEDED",
    "engineering": "PASSED"
  },
  "model_usage": {
    "kind": "api",
    "requests": 2,
    "reservations": 2,
    "input_tokens": 29619,
    "output_tokens": 2347,
    "total_tokens": 31966,
    "missing_usage_requests": 0,
    "notice": "Counts include retries and repairs; tokens are provider-reported only; missing usage is not zero."
  },
  "workflow_runtime_seconds": 65.745360404253,
  "resources": {
    "peak_memory_bytes": null,
    "cpu_seconds": null,
    "reason": "not_measured; sandbox limits are not measurements"
  },
  "peak_memory": "NOT_MEASURED; container limits are not measurements",
  "failure": null
}
```

## B. 当前检测数据

```json
{
  "frozen_source": {
    "display_name": "sim-cpu_spike-v1",
    "end_at_inclusive": "2026-01-04T04:59:00+00:00",
    "host_id": "sim-host-a",
    "metric": "cpu_utilization",
    "missing_points": 1,
    "points": 300,
    "roles": {
      "calibration": {
        "path": "calibration.csv",
        "prefix_points": 60,
        "sha256": "sha256:62206c6f4ee9c407f7e6f14b813c7c3efad96c619dd34d79f6b476fc36fcebfa"
      },
      "development": {
        "path": "development.csv",
        "prefix_points": 60,
        "sha256": "sha256:0b1c89ed190907f0eee98d5e596ce91e454fd31b4711b93348f3ddba200bb102"
      },
      "test": {
        "path": "test.csv",
        "prefix_points": 60,
        "sha256": "sha256:5f75ccda28286bfe234d2044c7cba72316fe303eb54848fdd826e33fa41bbbf0"
      },
      "train": {
        "path": "train.csv",
        "prefix_points": 60,
        "sha256": "sha256:0375d106a795e326c12156ed1842f65f3b8a5b6687370547dfa082064bac332d"
      }
    },
    "sampling_seconds": 60,
    "start_at": "2026-01-04T00:00:00+00:00",
    "type": "builtin_simulation",
    "unit": "percent"
  },
  "selection": {
    "basis": "labelled_development",
    "beta": 1.0,
    "criteria": [
      "event_f1_desc",
      "point_f1_desc",
      "false_alarm_rate_asc",
      "matched_delay_asc",
      "coverage_desc",
      "candidate_id"
    ],
    "objective": "event_detection",
    "policy": "balanced",
    "protocol": "metrics-selection/2",
    "ranking": [
      "fixed_threshold_cpu_upper_90_p3"
    ],
    "reason": "按开发集目标及次级 Fβ、正常误报频次、匹配延迟、覆盖率和候选ID排序；最终测试不参与选择。",
    "requested_policy": "balanced",
    "selected": "fixed_threshold_cpu_upper_90_p3",
    "status": "SELECTED",
    "tie_broken_by": "only_eligible_candidate",
    "warnings": [
      "LOW_EVENT_COUNT: 真实事件少于5个，事件F1不足以支持统计结论。"
    ]
  },
  "result": {
    "acceptance_status": "MEASURED_NO_ACCEPTANCE_THRESHOLD",
    "coverage": {
      "denominator": 240,
      "null_reason": null,
      "numerator": 240,
      "value": 1.0
    },
    "effect_status": "MEASURED",
    "engineering_status": "PASSED",
    "event": {
      "f1": {
        "denominator": 5,
        "null_reason": null,
        "numerator": 4,
        "value": 0.8
      },
      "fn": 1,
      "fp": 0,
      "pairs": [
        {
          "delay_seconds": 120.0,
          "prediction_id": "pred-0000",
          "truth_id": "truth-0000"
        },
        {
          "delay_seconds": 120.0,
          "prediction_id": "pred-0001",
          "truth_id": "truth-0002"
        }
      ],
      "precision": {
        "denominator": 2,
        "null_reason": null,
        "numerator": 2,
        "value": 1.0
      },
      "recall": {
        "denominator": 3,
        "null_reason": null,
        "numerator": 2,
        "value": 0.6666666666666666
      },
      "tp": 2,
      "unmatched_prediction_ids": [],
      "unmatched_truth_ids": [
        "truth-0001"
      ]
    },
    "execution_status": "SUCCEEDED",
    "matched_delay_seconds": {
      "maximum": 120.0,
      "median": 120.0,
      "missed_events": 1,
      "null_reason": null
    },
    "normal_false_alarms_per_host_hour": {
      "denominator": 13860,
      "null_reason": null,
      "numerator": 0,
      "value": 0.0
    },
    "peak_memory_bytes": null,
    "peak_memory_null_reason": "not_measured",
    "phase": "test",
    "point": {
      "abstained_normal": 0,
      "f1": {
        "denominator": 13,
        "null_reason": null,
        "numerator": 8,
        "value": 0.6153846153846154
      },
      "fn": 5,
      "fp": 0,
      "precision": {
        "denominator": 4,
        "null_reason": null,
        "numerator": 4,
        "value": 1.0
      },
      "recall": {
        "denominator": 9,
        "null_reason": null,
        "numerator": 4,
        "value": 0.4444444444444444
      },
      "tn": 231,
      "total": 240,
      "tp": 4
    },
    "predicted_events": [
      {
        "end_at": "2026-01-04T01:38:00Z",
        "event_id": "pred-0000",
        "host_id": "sim-host-a",
        "metric": "cpu_utilization",
        "start_at": "2026-01-04T01:37:00Z",
        "trigger_at": "2026-01-04T01:37:00Z"
      },
      {
        "end_at": "2026-01-04T04:05:00Z",
        "event_id": "pred-0001",
        "host_id": "sim-host-a",
        "metric": "cpu_utilization",
        "start_at": "2026-01-04T04:02:00Z",
        "trigger_at": "2026-01-04T04:02:00Z"
      }
    ],
    "protocol": "metrics-evaluation/1",
    "runtime_seconds": 0.10367242246866226,
    "selected": "fixed_threshold_cpu_upper_90_p3",
    "selection_sha256": "sha256:f0c2ce4539c38f81e036029900468f7f9a755b45d6dea8a5a777239f669bc95d",
    "test_execution_started": true,
    "truth_events": [
      {
        "end_at": "2026-01-04T01:38:00Z",
        "event_id": "truth-0000",
        "host_id": "sim-host-a",
        "metric": "cpu_utilization",
        "start_at": "2026-01-04T01:35:00Z",
        "trigger_at": "2026-01-04T01:35:00Z"
      },
      {
        "end_at": "2026-01-04T03:01:00Z",
        "event_id": "truth-0001",
        "host_id": "sim-host-a",
        "metric": "cpu_utilization",
        "start_at": "2026-01-04T03:00:00Z",
        "trigger_at": "2026-01-04T03:00:00Z"
      },
      {
        "end_at": "2026-01-04T04:05:00Z",
        "event_id": "truth-0002",
        "host_id": "sim-host-a",
        "metric": "cpu_utilization",
        "start_at": "2026-01-04T04:00:00Z",
        "trigger_at": "2026-01-04T04:00:00Z"
      }
    ]
  },
  "notice": null
}
```

## C. 独立模拟基准效果

```json
{
  "notice": "这些指标属于独立模拟基准，不代表上传数据的准确率或生产效果。",
  "result": {
    "execution_status": "NOT_EVALUATED",
    "reason": "builtin simulation evaluated in B"
  }
}
```

## D. 需求理解与业务验收

```json
{
  "frozen_task": {
    "acceptance_criteria": {
      "max_false_alarms_per_hour": null,
      "min_event_f1": null,
      "min_event_recall": null
    },
    "allowed_methods": [
      "fixed_threshold"
    ],
    "anomaly_target": "upper",
    "budgets": {
      "candidates": 1,
      "model_calls": 16,
      "repair_rounds": 2,
      "wall_seconds": 900
    },
    "dataset_id": "sim-cpu_spike-v1",
    "evaluation_objective": "event_detection",
    "explicit_constraints": {
      "direction": "upper",
      "persistence_points": 3.0,
      "threshold": 90.0
    },
    "knowledge_snapshot": "sha256:919e8bf13131bfe328ddfb4108fcb9eafc8673b74be9b85b774f428739151dcb",
    "metric": "cpu_utilization",
    "model_mode": "api",
    "model_profile_id": "metrics-c9a0036e73b91ba3",
    "ranking_preferences": [],
    "requirement": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
    "requirement_draft": {
      "binding": "sha256:b44aa5f27ab7fbb8441ce46aa7337a3cc6b06d994a6c99e2127013aff2fc84cc",
      "defaults": [
        "选优偏好：balanced",
        "评价目标：event_detection",
        "模拟数据：每 60 秒一点，独立四段；允许最多前向填补 3 点。",
        "未明确变化形态：CPU默认突增、内存默认阶跃模拟场景；模拟结果不代表生产效果。"
      ],
      "evidence": {
        "data_source": {
          "origin": "user_explicit",
          "quote": "模拟",
          "turn": 1
        },
        "direction": {
          "origin": "user_explicit",
          "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
          "turn": 1
        },
        "evaluation_objective": {
          "origin": "protocol_default",
          "quote": "协议默认值",
          "turn": 0
        },
        "methods": {
          "origin": "user_explicit",
          "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
          "turn": 1
        },
        "persistence_points": {
          "origin": "user_explicit",
          "quote": "连续 3 个采样点",
          "turn": 1
        },
        "scenario": {
          "origin": "user_explicit",
          "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
          "turn": 1
        },
        "selection_policy": {
          "origin": "protocol_default",
          "quote": "协议默认值",
          "turn": 0
        },
        "threshold": {
          "origin": "user_explicit",
          "quote": "超过 90%",
          "turn": 1
        }
      },
      "issues": [],
      "model_mode": "api",
      "model_usage": {
        "input_tokens": 975,
        "kind": "api",
        "missing_usage_requests": 0,
        "notice": "Counts include retries and repairs; tokens are provider-reported only; missing usage is not zero.",
        "output_tokens": 128,
        "requests": 1,
        "reservations": 1,
        "total_tokens": 1103
      },
      "parse_task_id": "understand-343cee7162864ae0",
      "revision": 1,
      "schema_version": "metrics-requirement-draft/1",
      "turns": [
        "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。"
      ],
      "values": {
        "data_source": "simulation",
        "direction": "upper",
        "evaluation_objective": "event_detection",
        "methods": [
          "fixed_threshold"
        ],
        "persistence_points": 3,
        "scenario": "cpu_spike",
        "selection_policy": "balanced",
        "threshold": 90.0
      }
    },
    "schema_version": "metrics-task/1",
    "selection_policy": "balanced",
    "task_id": "ui-34a756c1b4ac490b",
    "validation_protocol": "metrics-evaluation/1"
  },
  "selection_explanation": {
    "评价目标": "事件发现",
    "实际选优偏好": "综合选优",
    "比较依据": "有标签开发集",
    "排序顺序": "开发事件 F1 → 开发点级 F1 → 开发正常误报频次（升序） → 开发匹配延迟（升序） → 开发覆盖率（降序） → 候选标识（稳定决胜）",
    "实际决胜项": "仅一个合格候选"
  },
  "evaluation_policy": null,
  "requirement": {
    "binding": "sha256:b44aa5f27ab7fbb8441ce46aa7337a3cc6b06d994a6c99e2127013aff2fc84cc",
    "defaults": [
      "选优偏好：balanced",
      "评价目标：event_detection",
      "模拟数据：每 60 秒一点，独立四段；允许最多前向填补 3 点。",
      "未明确变化形态：CPU默认突增、内存默认阶跃模拟场景；模拟结果不代表生产效果。"
    ],
    "evidence": {
      "data_source": {
        "origin": "user_explicit",
        "quote": "模拟",
        "turn": 1
      },
      "direction": {
        "origin": "user_explicit",
        "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
        "turn": 1
      },
      "evaluation_objective": {
        "origin": "protocol_default",
        "quote": "协议默认值",
        "turn": 0
      },
      "methods": {
        "origin": "user_explicit",
        "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
        "turn": 1
      },
      "persistence_points": {
        "origin": "user_explicit",
        "quote": "连续 3 个采样点",
        "turn": 1
      },
      "scenario": {
        "origin": "user_explicit",
        "quote": "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。",
        "turn": 1
      },
      "selection_policy": {
        "origin": "protocol_default",
        "quote": "协议默认值",
        "turn": 0
      },
      "threshold": {
        "origin": "user_explicit",
        "quote": "超过 90%",
        "turn": 1
      }
    },
    "issues": [],
    "model_mode": "api",
    "model_usage": {
      "input_tokens": 975,
      "kind": "api",
      "missing_usage_requests": 0,
      "notice": "Counts include retries and repairs; tokens are provider-reported only; missing usage is not zero.",
      "output_tokens": 128,
      "requests": 1,
      "reservations": 1,
      "total_tokens": 1103
    },
    "parse_task_id": "understand-343cee7162864ae0",
    "revision": 1,
    "schema_version": "metrics-requirement-draft/1",
    "turns": [
      "用模拟数据生成单主机 CPU 异常检测程序。超过 90% 且连续 3 个采样点才报警，只使用固定阈值，输出代码和验证报告。"
    ],
    "values": {
      "data_source": "simulation",
      "direction": "upper",
      "evaluation_objective": "event_detection",
      "methods": [
        "fixed_threshold"
      ],
      "persistence_points": 3,
      "scenario": "cpu_spike",
      "selection_policy": "balanced",
      "threshold": 90.0
    }
  },
  "acceptance": {
    "checks": [],
    "status": "NOT_DEFINED"
  },
  "criteria": {
    "max_false_alarms_per_hour": null,
    "min_event_f1": null,
    "min_event_recall": null
  }
}
```
