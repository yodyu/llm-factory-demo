# 数值监控算法运行报告

任务：metrics-memory-real-v1
来源：llm_api；流程状态：COMPLETED

数据为模拟数据；工程通过、效果已测量及业务达标分别记录。业务门槛未定义。

| 候选 | 方法 | 版本数 | 工程状态 | 开发事件 F1 | 覆盖率 |
| --- | --- | --- | --- | --- | --- |
| memory_utilization_fixed_u85_p2 | fixed_threshold | 1 | PASSED | 1.0 | 1.0 |
| memory_utilization_rolling_mad_upper_w30_h15_q99_p2 | rolling_mad | 3 | FAILED | None | None |

## 冻结与最终测试

```json
{
  "selection": {
    "status": "SELECTED",
    "ranking": [
      "memory_utilization_fixed_u85_p2"
    ],
    "selected": "memory_utilization_fixed_u85_p2"
  },
  "final": {
    "protocol": "metrics-evaluation/1",
    "execution_status": "SUCCEEDED",
    "engineering_status": "PASSED",
    "effect_status": "MEASURED",
    "acceptance_status": "MEASURED_NO_ACCEPTANCE_THRESHOLD",
    "point": {
      "tp": 59,
      "fp": 0,
      "fn": 1,
      "tn": 180,
      "abstained_normal": 0,
      "total": 240,
      "precision": {
        "value": 1.0,
        "numerator": 59,
        "denominator": 59,
        "null_reason": null
      },
      "recall": {
        "value": 0.9833333333333333,
        "numerator": 59,
        "denominator": 60,
        "null_reason": null
      },
      "f1": {
        "value": 0.9915966386554622,
        "numerator": 118,
        "denominator": 119,
        "null_reason": null
      }
    },
    "event": {
      "tp": 1,
      "fp": 0,
      "fn": 0,
      "pairs": [
        {
          "truth_id": "truth-0000",
          "prediction_id": "pred-0000",
          "delay_seconds": 60.0
        }
      ],
      "unmatched_truth_ids": [],
      "unmatched_prediction_ids": [],
      "precision": {
        "value": 1.0,
        "numerator": 1,
        "denominator": 1,
        "null_reason": null
      },
      "recall": {
        "value": 1.0,
        "numerator": 1,
        "denominator": 1,
        "null_reason": null
      },
      "f1": {
        "value": 1.0,
        "numerator": 2,
        "denominator": 2,
        "null_reason": null
      }
    },
    "coverage": {
      "value": 1.0,
      "numerator": 240,
      "denominator": 240,
      "null_reason": null
    },
    "normal_false_alarms_per_host_hour": {
      "value": 0.0,
      "numerator": 0,
      "denominator": 10800,
      "null_reason": null
    },
    "matched_delay_seconds": {
      "median": 60.0,
      "maximum": 60.0,
      "null_reason": null,
      "missed_events": 0
    },
    "runtime_seconds": 0.0770748145878315,
    "peak_memory_bytes": null,
    "peak_memory_null_reason": "not_measured",
    "predicted_events": [
      {
        "event_id": "pred-0000",
        "host_id": "sim-host-a",
        "metric": "memory_utilization",
        "start_at": "2026-01-04T02:41:00Z",
        "end_at": "2026-01-04T03:40:00Z",
        "trigger_at": "2026-01-04T02:41:00Z"
      }
    ],
    "truth_events": [
      {
        "event_id": "truth-0000",
        "host_id": "sim-host-a",
        "metric": "memory_utilization",
        "start_at": "2026-01-04T02:40:00Z",
        "end_at": "2026-01-04T03:40:00Z",
        "trigger_at": "2026-01-04T02:40:00Z"
      }
    ],
    "selection_sha256": "sha256:b4dc177466d698fc192901e7f888384467c1cc02f4d7e46aab8a853d786a8df6",
    "selected": "memory_utilization_fixed_u85_p2",
    "phase": "test",
    "test_execution_started": true
  },
  "failure": null,
  "bindings": {
    "manifest_sha256": "sha256:fa1285126d0d20c64f69aacafd732f851b54b704de045560cea5cfc11374e285",
    "knowledge_snapshot": "sha256:65456cc48ddd39d06f9ac701bab4469392f4a0d37dbddc533967764a539565f7",
    "image_id": "sha256:4ac57c88b37dae806e1542718e900f497dca56f3d8030bd4211d16193108162c",
    "labels_sha256": "sha256:6a517b2eb58c8139863a5c9439b37bde43e1e4a4b0486a6d1ae94bc395e24be5"
  }
}
```

## 模型与知识证据

检索模式：structured；快照：sha256:65456cc48ddd39d06f9ac701bab4469392f4a0d37dbddc533967764a539565f7

本任务模型操作记录数：5（mock 操作不是真实请求）。
共享调用额度：{'limit': 60, 'reserved': 16, 'sent': 16, 'remaining': 44, 'accounting': 'reserved slots include uncertain or interrupted requests; no refunds'}

最终测试结果没有进入修复或重新选择。失败版本保留在候选目录中。
峰值内存未测量；沙箱限制不能替代实测。
